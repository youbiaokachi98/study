// 自ECMAScript 2015起，symbol成为了一种新的原生类型

// symbol类型的值是通过Symbol构造函数创建的。
let sym1: symbol = Symbol(1);
let sym2: symbol = Symbol(1);

// Symbols是不可改变且唯一的。
sym1 === sym2; // false
// 那么如何让两个symbol的值相等呢？ Symbol.for(string)
Symbol.for('1') == Symbol.for('1'); // true
/* 
    Symbol.for()会接受一个string作为入参，搜索有没有以这个参数作为名称的Symbol值
    如果有就返回这个Symbol值，没有就创建一个
*/

/* 
    那么问题来了？使用Symbol()创建的symbol值和使用Symbol.for()创建的symbol值有什么区别呢？
    这两种值都会生成一个新的symbol，区别是：
    使用Symbol.for()创建,会被登记在全局环境中供搜索(登记机制)，它在创建时，会先检查全局环境中给定的key值是否存在，
    如果不存在，那么就创建一个。
    通俗来说，比如你创建了Symbol.for("key")调用了100次，每次都返回的同一个Symbol值，但是用Symbol()会返回
    100个不同的Symbol值
*/

// 像字符串一样，symbols也可以被用做对象属性的键。
let obj = {
  name: '张三',
  [sym1]: 111,
  [sym2]: 222,
};
// 我想遍历obj的属性,包括Symbol属性
// 1. for in 
for (const key in obj) {
    console.log(key);  // name
}
// 2. Object.keys()
console.log(Object.keys(obj));  // ["name"]
// 3. Object.getOwnPropertyNames()
console.log(Object.getOwnPropertyNames(obj)); // ["name"]
// 4. Object.getOwnPropertySymbols()
console.log(Object.getOwnPropertySymbols(obj)); // [ Symbol(1), Symbol(1) ]
// 5.Reflect.ownKeys()
console.log(Reflect.ownKeys(obj));  // [ 'name', Symbol(1), Symbol(1) ]

