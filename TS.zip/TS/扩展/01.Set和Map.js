/* 
    set: 类似于数组，成员的值是唯一的，Set本身是一个构造函数

*/
let set = new Set();
// 通过add()向set中添加成员
set.add(1);
set.add(2);
set.add(3);
console.log(set);
// set可以传递一个数组，从而初始化
let set1 = new Set([1, 2, 3, 4]);
console.log([...set1]);  // [ 1, 2, 3, 4 ]
