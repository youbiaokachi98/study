namespace B{
    export const b = 2;
}

console.log(B.b);
