namespace A{
    export const a = 1;
}
console.log(A.a);
