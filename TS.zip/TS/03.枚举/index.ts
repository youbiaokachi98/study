// 枚举 enum
// 1.数字枚举
enum Gender {
  Male = 0,
  Female = 1,
}
// 注意一：默认情况下,从0开始为元素编号
enum Gender1 {
  Male,
  Female,
}
// 注意二：增长枚举，定义Male为1，则Female自动为2，剩余的成员会从1开始自动增长
enum Gender2 {
  Male = 1,
  Female,
}

// 2.字符串枚举
enum Gender3 {
  Male = 'male',
  Female = 'female',
}

// 3.异构枚举，通俗点就是枚举可以混合字符串和数字成员
enum BooleanEnum {
  No = 0,
  Yes = 'YES',
}

// 4.联合枚举与枚举成员的类型
enum Gender4 {
  Male = 0,
  Female = 1,
}

interface Person {
  name: string;
  sex: Gender4;
}
let p: Person = {
  name: '张三',
  sex: Gender4.Male,
};

// 4.反向映射，即从枚举值到枚举名字
enum Gender5 {
  Male = 0,
  Female = 1,
}
let x: number = Gender5.Male;
let enumName = Gender5[x];

// 扩展：const枚举，即常量枚举，可以避免在额外生成的代码上的开销和额外的非直接的对枚举成员的访问
// 需要注意的是，不会为字符串枚举成员生成反向映射
const enum Enum {
    A = 1,
    B = A * 2
}