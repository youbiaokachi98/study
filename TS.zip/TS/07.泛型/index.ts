// 泛型是什么？有什么作用？

// 当我们定义一个变量不确定的类型是有两种方式：any 或者 泛型
// 1.使用any
// 但是失去了ts类型保护的优势
// 2.泛型
// 泛型指的是在定义函数、接口、类型时，不指定具体的类型，而是在使用的时候再指定类型的一种特性

// 举例:
// 定义一个identity函数
function identity1(value: number): number {
  return value;
}
console.log(identity1(1)); // 1
// 如果像上面这样定义，这个函数就没有了复用性

function identity2<T>(value: T): T {
  return value;
}
// 我们给identity添加了类型变量T，T帮助我们捕获用户传入的类型，这里是number
// 两种方法调用这种泛型函数
// 第一种： 传入所有的参数，包含类型参数：
let output1 = identity2<string>('111');
// 第二种：利用了类型推论, 普遍使用
let output2 = identity2(111);

// ----泛型的用法
// 1.在函数中使用泛型
function test<T>(value: T): T {
  return value;
}
test(111)
test("111")
test(true)

// 2.在接口中使用泛型
interface A{
    
}

