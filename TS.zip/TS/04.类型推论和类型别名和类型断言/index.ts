// 类型推论，类型是在哪里如何被推断的
// 在TS中,某些没有明确指定类型的地方，TS的类型推断机制会帮助提供类型
// 发生类型推断的2种常见场景：1.声明变量并初始化  2.决定函数返回值时
let str = 'str';
// str = 111;  报错，因为ts已经将它推断成一个string类型
function add(num1: number, num2: number) {
  return num1 + num2;
}

// 类型别名
type myType1 = string | number;
let var1: myType1 = 'str';
let var2: myType1 = 2222;

// 扩展ts中类型的层次
/* 
    unknown             any    顶级类型
             Object
    Number   String   Boolean
    number   string   boolean
       1      "str"    true
              never
*/
type num = 1 extends number ? 1 : 0; // num = 1

// 类型断言
// 类型断言好比其它语言里的类型转换，但是不进行特殊的数据检查和解构
// 类型断言有两种形式

// 1.“尖括号”语法：
let someValue: any = 'this is a string';

let strLength: number = (<string>someValue).length;
// 2.as语法：
let someValue: any = 'this is a string';

let strLength: number = (someValue as string).length;
type MyType3 = '唱' | '跳' | 'rap';

let str11 = 'str';
const str1122 = 'str';
/* 
  为什么会出现上面的原因呢？
  解释：
    1.str1是一个变量（let）,它的值可以是任意字符串，所以类型是 string
    2.str2是一个常量（const）,它的值只能是 'str'，所以它的类型是 str
*/

type Direction = 'UP' | 'DOWN' | 'LEFT' | 'RIGHT';
function changeDirection(direction: Direction) {}
