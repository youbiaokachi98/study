
// 1.函数定义类型和返回值
function fn1(): void {}
function fn2(a: number, b: number): number {
  return a + b;
}

// 2.函数默认参数 | 函数可选参数（可选参数必须跟在必须参数后面）| 剩余参数
function fn3(a: number = 20, b?: number): any {
  // return a + b;
  // 注意 可选参数在严格模式下会报错，b未定义
}
function fn4(str: string, ...restOfName: string[]): string {
  return str + restOfName.join('');
}
let returnStr = fn4('hello', ' ', 'world');
console.log(returnStr);

// 3.函数的参数是一个对象
interface useObj {
  name: string;
  age: number;
}
function f4(user: useObj): useObj {
  return user;
}

// 4. 函数的this类型
// ts中可以定义this的类型，必须是第一个参数定义this的类型
interface group {
  user: number[];
  add: (this: group, num: number) => void;
}
let userobj: group = {
  user: [1, 2, 3],
  add(this: group, num: number) {
    this.user.push(num);
  },
};
userobj.add(4);
console.log(userobj.user);

// 5.函数的重载
let userArr: number[] = [1, 2, 3];
function findNum(ids?: number | number[]): number[] {
  if (Array.isArray(ids)) {
    userArr.push(...ids);
    return userArr;
  } else if (typeof ids == 'number') {
    return userArr.filter((item) => {
      return item == ids;
    });
  } else {
    return userArr;
  }
}