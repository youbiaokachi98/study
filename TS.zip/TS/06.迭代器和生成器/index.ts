// 生成器
function* gen() {
  yield Promise.resolve('resolve');
  yield 'str1';
  yield 'str2';
  yield 'str3';
}

let man = gen();
console.log(man.next()); // { value: Promise { 'resolve' }, done: false }
console.log(man.next()); // { value: 'str1', done: false }
console.log(man.next()); // { value: 'str1', done: false }
console.log(man.next()); // { value: 'str1', done: false }
console.log(man.next()); // { value: undefined, done: true }
// 可以通过done的值，判断生成器还是否可以迭代

// 迭代器
// 当一个对象实现了Symbol.iterator属性时，我们认为它是可迭代的

const each = (value: any) => {
  let It: any = value[Symbol.iterator]();
  let next: any = { done: false };
  while (!next.done) {
    next = It.next();
    if (!next.done) {
      console.log(next.value);
    }
  }
};
// 迭代器的语法糖  for...of，对象不能使用

// 解构，底层原理就是去调用iterator
// 那么如何让对象也支持for...of呢
let obj1 = {
  max: 5,
  current: 0,
  [Symbol.iterator]() {
    return {
      max: this.max,
      current: this.current,
      next() {
        if (this.current == this.max) {
          return {
            value: undefined,
            done: false,
          };
        } else {
          return {
            value: this.current++,
            done: true,
          };
        }
      },
    };
  },
};
for (let value of obj1) {
  console.log(value);
}
