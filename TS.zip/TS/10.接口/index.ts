// 接口
// 如果两个接口之间有相同的属性和方法，可以将公共的属性和方法抽离出来，通过继承来复用
interface Point2D {
  x: number;
  y: number;
}
interface Point3D extends Point2D {
  z: number;
}
let point3d: Point3D = {
  x: 1,
  y: 2,
  z: 3,
};
// 一个接口也可以继承多个接口，创建出多个接口的合成接口

// 可选属性
interface SquareConfig {
  color?: string;
  width?: number;
}

// 只读属性
// 一些对象属性只能在对象刚刚创建的时候修改其值。 你可以在属性名前用 readonly来指定只读属性
interface Point {
  readonly x: number;
  readonly y: number;
}
let p1: Point = { x: 10, y: 20 };
// p1.x = 5; // error!
// ReadonlyArray<T>类型
let ro: ReadonlyArray<number> = [1, 2, 3, 4];
// ro[0] = 12; // error!